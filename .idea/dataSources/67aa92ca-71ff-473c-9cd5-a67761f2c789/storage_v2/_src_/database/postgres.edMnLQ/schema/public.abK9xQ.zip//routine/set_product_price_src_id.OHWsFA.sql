create function set_product_price_src_id() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.PRODUCT_PRICE_SRC_ID := CAST(NEW.PRODUCT_PRICE_ID AS VARCHAR(255));
    RETURN NEW;
END;
$$;

alter function set_product_price_src_id() owner to postgres;


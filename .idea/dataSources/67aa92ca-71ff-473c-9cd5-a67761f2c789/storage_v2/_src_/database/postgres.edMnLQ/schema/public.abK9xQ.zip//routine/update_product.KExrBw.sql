create function update_product(product_id integer, column_name character varying, new_value character varying) returns void
    language plpgsql
as
$$
BEGIN
    EXECUTE 'UPDATE Products SET ' || column_name || ' = ' || quote_literal(new_value) || ' WHERE product_id = ' || product_id;
END;
$$;

alter function update_product(integer, varchar, varchar) owner to postgres;


create function set_shipment_src_id() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.SHIPMENT_SRC_ID := CAST(NEW.SHIPMENT_ID AS VARCHAR(255));
    RETURN NEW;
END;
$$;

alter function set_shipment_src_id() owner to postgres;

